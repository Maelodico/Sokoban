<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.4" name="cartes" tilewidth="32" tileheight="32" tilecount="416" columns="26">
 <image source="../../../Downloads/kenney_sokobanpack/Tilesheet/sokoban_tilesheet.png" trans="000000" width="832" height="512"/>
</tileset>
