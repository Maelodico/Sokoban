<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.4" name="nature" tilewidth="32" tileheight="32" tilecount="180" columns="20">
 <image source="nature.png" trans="000000" width="641" height="288"/>
</tileset>
